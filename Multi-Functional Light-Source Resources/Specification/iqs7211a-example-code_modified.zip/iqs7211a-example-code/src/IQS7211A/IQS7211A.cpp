/**
  **********************************************************************************
  * @file     IQS7211A.cpp
  * @author   Azoteq
  * @version  V1.0.0
  * @date     2021-07-06
  * @brief    This file contains the constructors and methods which allow ease of
  *           use of an IQS7211A capactive touch controller. The IQS7211A is a capacitive
  *           touch Integrated Circuit (IC) which provides multiple channel
  *           functionality. This class provides an easy means of initializing
  *           and interacting with the IQS7211A device from an Arduino.
  **********************************************************************************
  * @attention  Makes use of the following standard Arduino libraries:
  * - Arduino.h -> Included in IQS7211A.h, comes standard with Arduino
  * - Wire.h    -> Included in IQS7211A.h, comes standard with Arduino
  *
  **********************************************************************************
  */

// Include Files
#include "IQS7211A.h"
#include "IQS7211A_init_AZP1149A1.h"
// Private Definitions

// Private Global Variables


/**************************************************************************************************************/
/*                                                CONSTRUCTORS                                                */
/**************************************************************************************************************/
IQS7211A::IQS7211A(){
}

/**************************************************************************************************************/
/*                                              PUBLIC METHODS                                                */
/**************************************************************************************************************/

/**
  * @name   begin
  * @brief  A method to initialize the IQS7211A device with the device address and ready pin specified by the user.
  * @param  deviceAddress -> The address of the IQS7211A device.
  *         readyPin      -> The Arduino pin which is connected to the ready pin of the IQS7211A device.
  * @retval Returns true if communication has been successfully established, returns false if not.
  * @notes  Receiving a true return value does not mean that initialization was successful.
  *         Receiving a true return value only means that the IQS device responded to the request for communication.
  *         Receiving a false return value means that initialization did not take place at all.
  *         If communication is successfully established then it is unlikely that initialization will fail.
  */
bool IQS7211A::begin(uint8_t deviceAddressIn, uint8_t readyPinIn, uint8_t mclrPinIn)
{
  // Initialize I2C communication here, since this library can't function without it.
  Wire.begin();
  Wire.setClock(400000);

  bool response = false; // The return value.
  _deviceAddress = deviceAddressIn;
  _readyPin = readyPinIn;
  pinMode(_readyPin, INPUT);
  pinMode(mclrPinIn, OUTPUT);

  // Hardware Reset - Will still work without this
  digitalWrite(mclrPinIn, LOW);
  delay(1);
  digitalWrite(mclrPinIn, HIGH);

  // Request communication and run ATI routine.
  response = waitForReady();

  return response;
}

/**
  * @name  waitForReady
  * @brief  A method which waits for the IQS7211A device to pull the ready pin low.
  *     If there is no response for 100ms a false value is returned and the user can then either force communication 
  *     by using the method described in section 11.9.2 in the datasheet or just wait longer by placing this method in a while loop.
  * @param  None.
  * @retval Boolean: True if a response is received within 100ms, false if not.
  * @notes  Use this function when the device is in stream mode and you want the master to await communication from the IQS7211A device.
  *     If you want the master to initiate communication use the Force Communication method.
  *     For optimal program flow, it is suggested that RDY is used to sync on new data. The forced/polling
  *     method is only recommended if the master must perform I2C and Event Mode is active.
  */
bool IQS7211A::waitForReady(void)
{
  bool readyLow = false;      // The return value. Set to true if the ready pin is pulled low by the IQS7211A within 100ms.
  uint16_t notReadyCount = 0 ;  // Increments every time the loop executes to keep track of how long the request is going on.
  
  // Wait for communication from IQS7211A device. Timeout after 100ms.
  while(digitalRead(_readyPin))
  {
    notReadyCount++;
    delayMicroseconds(100);
    
    if((notReadyCount%1000) == 0)
      return readyLow;
  }
  // If the processing gets here then a response has been received.
  readyLow = true;
  return readyLow;
}

/**
  * @name	checkReset
  * @brief  A method which checks if the device has reset and returns the reset status.
  * @param  None.
  * @retval Returns true if a reset has occurred, false if no reset has occurred.
  * @notes  If a reset has occurred the device settings should be reloaded using the begin function.
  * 		After new device settings have been reloaded the acknowledge reset function can be used
  * 		to clear the reset flag.
  */
bool IQS7211A::checkReset(void)
{
	IQSMemoryMap.iqs7211a_info_flags.iqs7211a_infoflags_lsb &= SHOW_RESET_BIT;
	// Return the reset status.
	if(IQSMemoryMap.iqs7211a_info_flags.iqs7211a_infoflags_lsb != 0)
		return true;
	else
		return false;
}

/**
  * @name	getProductNum
  * @brief  A method which reads the device product number and return a uint16 result.
  * @param  stopOrRestart -> Specifies whether the communications window must be kept open or must be closed after this action.
  *                          Use the STOP and RESTART definitions.
  * @retval Returns product number.
  * @notes  If the product is not correctly identified an appropriate messages should be displayed.
  */
uint16_t IQS7211A::getProductNum(bool stopOrRestart)
{
	uint8_t transferBytes[2];	// A temporary array to hold the byte to be transferred.
  uint8_t prodNumLow = 0;         // Temporary storage for the counts low byte.
  uint8_t prodNumHigh = 0;        // Temporary storage for the counts high byte.
  uint16_t prodNumReturn = 0;     // The 16bit return value.
								// Use an array to be consistent with other methods of the library.
	// Read the Device info from the IQS7211A.
	readRandomBytes(IQS7211A_MM_PROD_NUM, 2, transferBytes, stopOrRestart);

  // Construct the 16bit return value.
  prodNumLow = transferBytes[0];
  prodNumHigh = transferBytes[1];
  prodNumReturn = (uint16_t)(prodNumLow);
  prodNumReturn |= (uint16_t)(prodNumHigh<<8);
  // Return the product number value.
  return prodNumReturn;
}

/**
  * @name	getSoftwareMajorNum
  * @brief  A method which reads the device software major number and return a uint8 result.
  * @param  stopOrRestart -> Specifies whether the communications window must be kept open or must be closed after this action.
  *                          Use the STOP and RESTART definitions.
  * @retval Returns software major number.
  * @notes  If the device software major version is not correctly identified an appropriate messages should be displayed.
  */
uint8_t IQS7211A::getSoftwareMajorNum(bool stopOrRestart)
{
	uint8_t transferBytes[1];	// A temporary array to hold the byte to be transferred.
								// Use an array to be consistent with other methods of the library.
	// Read the Device info from the IQS7211A.
	readRandomBytes(IQS7211A_MM_MAJOR_VERSION_NUM, 1, transferBytes, stopOrRestart);
  return transferBytes[0];
}

/**
  * @name	getSoftwareMinorNum
  * @brief  A method which reads the device software minor number and return a uint8 result.
  * @param  stopOrRestart -> Specifies whether the communications window must be kept open or must be closed after this action.
  *                          Use the STOP and RESTART definitions.
  * @retval Returns software minor number.
  * @notes  If the device software minor version is not correctly identified an appropriate messages should be displayed.
  */
uint8_t IQS7211A::getSoftwareMinorNum(bool stopOrRestart)
{
	uint8_t transferBytes[1];	// A temporary array to hold the byte to be transferred.
								// Use an array to be consistent with other methods of the library.
	// Read the Device info from the IQS7211A.
	readRandomBytes(IQS7211A_MM_MINOR_VERSION_NUM, 1, transferBytes, stopOrRestart);
	return transferBytes[0];
}

/**
  * @name	acknowledgeReset
  * @brief  A method which clears the Show Reset bit by setting the Ack Reset Bit.
  * @param  stopOrRestart -> Specifies whether the communications window must be kept open or must be closed after this action.
  *                          Use the STOP and RESTART definitions.
  * @retval None.
  * @notes  If a reset has occurred the device settings should be reloaded using the begin function.
  * 		After new device settings have been reloaded this method should be used to clear the
  * 		reset bit.
  */
void IQS7211A::acknowledgeReset(bool stopOrRestart)
{
	uint8_t transferBytes[2];	// A temporary array to hold the bytes to be transferred.
	// Read the System Flags from the IQS7211A, these must be read first in order not to change any settings.
	// We are interested in the 2nd byte at the address location, therefore, we must read and write both bytes.
	readRandomBytes(IQS7211A_MM_SYSTEM_CONTROL, 2, transferBytes, RESTART);
	// SWrite the AAck Reset bit to 1 to clear the Show Reset Flag.
	transferBytes[0] |= ACK_RESET_BIT;
	// Write the new byte to the System Flags address.
	writeRandomBytes(IQS7211A_MM_SYSTEM_CONTROL, 2, transferBytes, stopOrRestart);
}

/**
  * @name   TP_ReATI
  * @brief  A method which sets the REDO_ATI_BIT in order to force the IQS7211A device to run the 
  *         Automatic Tuning Implementation (ATI) routine.
  * @param  stopOrRestart -> Specifies whether the communications window must be kept open or must be closed after this action.
  *                          Use the STOP and RESTART definitions.
  * @retval None.
  * @notes  To force ATI, bit 4 in PROX_SETTINGS_0 is set. PROX_SETTINGS_0 is byte 0 in the PROXSETTINGS_0_1 address.
  */
void IQS7211A::TP_ReATI(bool stopOrRestart)
{
  uint8_t transferByte[1]; // Array to store the bytes transferred.
  	  	  	  	  	  	   // Use an array to be consistent with other methods in this class.
  readRandomBytes(IQS7211A_MM_SYSTEM_CONTROL, 1, transferByte, RESTART);
  // Mask the settings with the REDO_ATI_BIT.
  transferByte[0] |= TP_REATI_BIT;  // This is the bit required to start an ATI routine.
  // Write the new byte to the required device.
  writeRandomBytes(IQS7211A_MM_SYSTEM_CONTROL, 1, transferByte, stopOrRestart);
}

/**
  * @name   SW_Reset
  * @brief  A method which sets the SW RESET bit in order to force the IQS7211A device to do a SW reset.
  * @param  stopOrRestart -> Specifies whether the communications window must be kept open or must be closed after this action.
  *                          Use the STOP and RESTART definitions.
  * @retval None.
  * @notes  To perform SW Reset, bit 9 in SYSTEM_CONTROL is set. 
  */
void IQS7211A::SW_Reset(bool stopOrRestart)
{
  uint8_t transferByte[2]; // Array to store the bytes transferred.
  	  	  	  	  	  	   // Use an array to be consistent with other methods in this class.
  readRandomBytes(IQS7211A_MM_SYSTEM_CONTROL, 2, transferByte, RESTART);
  // Mask the settings with the SW_RESET_BIT.
  transferByte[1] |= SW_RESET_BIT;  // This is the bit required to perform SW Reset.
  // Write the new byte to the required device.
  writeRandomBytes(IQS7211A_MM_SYSTEM_CONTROL, 2, transferByte, stopOrRestart);
}

/**
  * @name   updateCoordinates
  * @brief  A method which reads the IQS7211A x and y coordinates and assigns them to the coord info union.
  * @param  stopOrRestart -> Specifies whether the communications window must be kept open or closed after retrieving the information.
  *                          Use the STOP and RESTART definitions.
  * @param  fingerNum     -> Specifies the finger number. Finger 1 is the first finger to touch the trackpad, finger 2 is the second 
  *                          to touch the trackpad.
  * @retval None.
  * @notes  The coords union is altered with the new value of the coord info register.
  *         The user can use the getAbsXCoordinate and getAbsYCoordinate methods to return the value.
  */
void IQS7211A::updateAbsCoordinates(bool stopOrRestart, uint8_t fingerNum)
{
  uint8_t transferBytes[4]; // The temporary address which will hold the bytes from the IQS7211A_MM_FINGER_1_X address.
  if (fingerNum == FINGER_1)
  {
    // Read the bytes using the readRandomBytes method to read bytes at the IQS7211A_MM_FINGER_1_X address.
    readRandomBytes(IQS7211A_MM_FINGER_1_X, 4, transferBytes, stopOrRestart);
    //  Assign the bytes to the union.
    IQSMemoryMap.iqs7211a_coord_info.f1_x_lsb = transferBytes[0];
    IQSMemoryMap.iqs7211a_coord_info.f1_x_msb = transferBytes[1];
    IQSMemoryMap.iqs7211a_coord_info.f1_y_lsb = transferBytes[2];
    IQSMemoryMap.iqs7211a_coord_info.f1_y_msb = transferBytes[3];
  }
  else if (fingerNum == FINGER_2)
  {
    // Read the bytes using the readRandomBytes method to read bytes at the IQS7211A_MM_FINGER_2_X address.
    readRandomBytes(IQS7211A_MM_FINGER_2_X, 4, transferBytes, stopOrRestart);
    //  Assign the bytes to the union.
    IQSMemoryMap.iqs7211a_coord_info.f2_x_lsb = transferBytes[0];
    IQSMemoryMap.iqs7211a_coord_info.f2_x_msb = transferBytes[1];
    IQSMemoryMap.iqs7211a_coord_info.f2_y_lsb = transferBytes[2];
    IQSMemoryMap.iqs7211a_coord_info.f2_y_msb = transferBytes[3];
  }
}

/**
  * @name	get_AbsXCoordinate
  * @brief  A method which returns the constructed 16bit coordinate value
  * @param  stopOrRestart -> Specifies whether the communications window must be kept open or must be closed after this action.
  *                          Use the STOP and RESTART definitions.
  * @param  fingerNum     -> Specifies the finger number. Finger 1 is the first finger to touch the trackpad, finger 2 is the second 
  *                          to touch the trackpad.
  * @retval Returns 16bit coordinate value.
  * @notes  
  */
uint16_t IQS7211A::getAbsXCoordinate(uint8_t fingerNum)
{
  uint16_t absXCoordReturn = 0;     // The 16bit return value.

  // Construct the 16bit return value.
  if (fingerNum == FINGER_1)
  {
    absXCoordReturn = (uint16_t)(IQSMemoryMap.iqs7211a_coord_info.f1_x_lsb);
    absXCoordReturn |= (uint16_t)(IQSMemoryMap.iqs7211a_coord_info.f1_x_msb << 8);
  }
  else if (fingerNum == FINGER_2)
  {
    absXCoordReturn = (uint16_t)(IQSMemoryMap.iqs7211a_coord_info.f2_x_lsb);
    absXCoordReturn |= (uint16_t)(IQSMemoryMap.iqs7211a_coord_info.f2_x_msb << 8);
  }
  // Return the coordinate value.Note that a value of 65535 means there is no touch.
  return absXCoordReturn; 
}

/**
  * @name	get_AbsYCoordinate
  * @brief  A method which returns the constructed 16bit coordinate value
  * @param  stopOrRestart -> Specifies whether the communications window must be kept open or must be closed after this action.
  *                          Use the STOP and RESTART definitions.
  * @param  fingerNum     -> Specifies the finger number. Finger 1 is the first finger to touch the trackpad, finger 2 is the second 
  *                          to touch the trackpad.
  * @retval Returns 16bit coordinate value.
  * @notes  
  */
uint16_t IQS7211A::getAbsYCoordinate(uint8_t fingerNum)
{
  uint16_t absYCoordReturn = 0;     // The 16bit return value.

  // Construct the 16bit return value.
  if (fingerNum == FINGER_1)
  {
    absYCoordReturn = (uint16_t)(IQSMemoryMap.iqs7211a_coord_info.f1_y_lsb);
    absYCoordReturn |= (uint16_t)(IQSMemoryMap.iqs7211a_coord_info.f1_y_msb << 8);
  }
  else if (fingerNum == FINGER_2)
  {
    absYCoordReturn = (uint16_t)(IQSMemoryMap.iqs7211a_coord_info.f2_y_lsb);
    absYCoordReturn |= (uint16_t)(IQSMemoryMap.iqs7211a_coord_info.f2_y_msb << 8);
  }
  // Return the coordinate value. Note that a value of 65535 means there is no touch.
  return absYCoordReturn; 
}

/**
  * @name   update_Gestures
  * @brief  A method which reads the gestures and assigns it to the gestures union.
  * @param  stopOrRestart -> Specifies whether the communications window must be kept open or closed after retrieving the information.
  *                          Use the STOP and RESTART definitions.
  * @retval None.
  * @notes  The gestures union is altered with the new value at the trackpad flags register.
  */
void IQS7211A::updateGestures(bool stopOrRestart)
{
  uint8_t transferBytes[1]; // The temporary address which will hold the GESTURE byte.

  // Read the byte using the readRandomByte method, only one byte is stored at the IQS7211A_MM_GESTURES address.
  readRandomBytes(IQS7211A_MM_GESTURES, 1, transferBytes, stopOrRestart);
  //  Assign the byte to the union.
  IQSMemoryMap.iqs7211a_gesture_events.iqs7211a_gesture_events_lsb = transferBytes[0];
}

/**
  * @name   setStreamMode
  * @brief  A method which sets the IQS7211A device into stream mode.
  * @param  stopOrRestart -> Specifies whether the communications window must be kept open or must be closed after this action.
  *                          Use the STOP and RESTART definitions.
  * @retval None. 
  * @notes  All other bits at the register address are preserved.
  */
void IQS7211A::setStreamMode(bool stopOrRestart)
{
  uint8_t transferBytes[2]; // The array which will hold the bytes which are transferred.

  // First read the bytes at the memory address so that they can be preserved.
  readRandomBytes(IQS7211A_MM_CONFIG_SETTINGS, 2, transferBytes, RESTART);
  // Clear the EVENT_MODE_BIT in CONFIG_SETTINGS
  transferBytes[1] &= ~(EVENT_MODE_BIT);
  // Write the bytes back to the device
  writeRandomBytes(IQS7211A_MM_CONFIG_SETTINGS, 2, transferBytes, stopOrRestart);
}

/**
  * @name   setEventMode
  * @brief  A method to set the IQS7211A device into event mode.
  * @param  stopOrRestart -> Specifies whether the communications window must be kept open or must be closed after this action.
  *              Use the STOP and RESTART definitions.
  * @retval None. 
  * @notes  All other bits at the register address are preserved.
  */
void IQS7211A::setEventMode(bool stopOrRestart)
{
  uint8_t transferBytes[2]; // The array which will hold the bytes which are transferred.

  // First read the bytes at the memory address so that they can be preserved.
  readRandomBytes(IQS7211A_MM_CONFIG_SETTINGS, 2, transferBytes, RESTART);
  // Set the EVENT_MODE_BIT in CONFIG_SETTINGS
  transferBytes[1] |= EVENT_MODE_BIT;
  // Write the bytes back to the device
  writeRandomBytes(IQS7211A_MM_CONFIG_SETTINGS, 2, transferBytes, stopOrRestart);
}

/**
  * @name   enableGestureEvent
  * @brief  A method to enable Gesture Events.  Gestures will trigger event.
  * @param  stopOrRestart -> Specifies whether the communications window must be kept open or must be closed after this action.
  *              Use the STOP and RESTART definitions.
  * @retval None. 
  * @notes  All other bits at the register address are preserved.
  */
void IQS7211A::enableGestureEvent(bool stopOrRestart)
{
  uint8_t transferBytes[2]; // The array which will hold the bytes which are transferred.

  // First read the bytes at the memory address so that they can be preserved.
  readRandomBytes(IQS7211A_MM_CONFIG_SETTINGS, 2, transferBytes, RESTART);
  // Set the GESTURE_EVENT_BIT in CONFIG_SETTINGS
  transferBytes[1] |= GESTURE_EVENT_BIT;
  // Write the bytes back to the device
  writeRandomBytes(IQS7211A_MM_CONFIG_SETTINGS, 2, transferBytes, stopOrRestart);
}

/**
  * @name   disableGestureEvent
  * @brief  A method to disable Gesture Events.  Gestures will not trigger event.
  * @param  stopOrRestart -> Specifies whether the communications window must be kept open or must be closed after this action.
  *              Use the STOP and RESTART definitions.
  * @retval None. 
  * @notes  All other bits at the register address are preserved.
  */
void IQS7211A::disableGestureEvent(bool stopOrRestart)
{
  uint8_t transferBytes[2]; // The array which will hold the bytes which are transferred.

  // First read the bytes at the memory address so that they can be preserved.
  readRandomBytes(IQS7211A_MM_CONFIG_SETTINGS, 2, transferBytes, RESTART);
  // Clear the GESTURE_EVENT_BIT in CONFIG_SETTINGS
  transferBytes[1] &= ~(GESTURE_EVENT_BIT);
  // Write the bytes back to the device
  writeRandomBytes(IQS7211A_MM_CONFIG_SETTINGS, 2, transferBytes, stopOrRestart);
}

/**
  * @name   enableTPEvent
  * @brief  A method to enable TP Events. Trackpad finger movement or finger up/down will trigger event.
  * @param  stopOrRestart -> Specifies whether the communications window must be kept open or must be closed after this action.
  *              Use the STOP and RESTART definitions.
  * @retval None. 
  * @notes  All other bits at the register address are preserved.
  */
void IQS7211A::enableTPEvent(bool stopOrRestart)
{
  uint8_t transferBytes[2]; // The array which will hold the bytes which are transferred.

  // First read the bytes at the memory address so that they can be preserved.
  readRandomBytes(IQS7211A_MM_CONFIG_SETTINGS, 2, transferBytes, RESTART);
  // Set the TP_EVENT_BIT in CONFIG_SETTINGS
  transferBytes[1] |= TP_EVENT_BIT;
  // Write the bytes back to the device
  writeRandomBytes(IQS7211A_MM_CONFIG_SETTINGS, 2, transferBytes, stopOrRestart);
}

/**
  * @name   disableTPEvent
  * @brief  A method to disable TP Events. Trackpad finger movement or finger up/down will not trigger event.
  * @param  stopOrRestart -> Specifies whether the communications window must be kept open or must be closed after this action.
  *              Use the STOP and RESTART definitions.
  * @retval None. 
  * @notes  All other bits at the register address are preserved.
  */
void IQS7211A::disableTPEvent(bool stopOrRestart)
{
  uint8_t transferBytes[2]; // The array which will hold the bytes which are transferred.

  // First read the bytes at the memory address so that they can be preserved.
  readRandomBytes(IQS7211A_MM_CONFIG_SETTINGS, 2, transferBytes, RESTART);
  // Clear the TP_EVENT_BIT in CONFIG_SETTINGS
  transferBytes[1] &= ~(TP_EVENT_BIT);
  // Write the bytes back to the device
  writeRandomBytes(IQS7211A_MM_CONFIG_SETTINGS, 2, transferBytes, stopOrRestart);
}

/**
  * @name   disableCommsReqEn
  * @brief  A method to disable Comms request Enable. 
  * @param  stopOrRestart -> Specifies whether the communications window must be kept open or must be closed after this action.
  *              Use the STOP and RESTART definitions.
  * @retval None. 
  * @notes  All other bits at the register address are preserved.
  *         You can call this method once to be able to poll the IQS device, otherwise you will need to enable Comms Req and use forceComms.
  *         See the datasheet for more detail on this.
  */
void IQS7211A::disableCommsReqEn(bool stopOrRestart)
{
  uint8_t transferBytes[2]; // The array which will hold the bytes which are transferred.

  // First read the bytes at the memory address so that they can be preserved.
  readRandomBytes(IQS7211A_MM_CONFIG_SETTINGS, 2, transferBytes, RESTART);
  // Set the TP_EVENT_BIT in CONFIG_SETTINGS
  transferBytes[0] &= ~(COMMS_REQ_EN_BIT);
  // Write the bytes back to the device
  writeRandomBytes(IQS7211A_MM_CONFIG_SETTINGS, 2, transferBytes, stopOrRestart);
}

/**
  * @name   enableCommsReqEn
  * @brief  A method to enable Comms request Enable. 
  * @param  stopOrRestart -> Specifies whether the communications window must be kept open or must be closed after this action.
  *              Use the STOP and RESTART definitions.
  * @retval None. 
  * @notes  All other bits at the register address are preserved.
  *         Call this method once if you want to use the forceComms method
  */
void IQS7211A::enableCommsReqEn(bool stopOrRestart)
{
  uint8_t transferBytes[2]; // The array which will hold the bytes which are transferred.

  // First read the bytes at the memory address so that they can be preserved.
  readRandomBytes(IQS7211A_MM_CONFIG_SETTINGS, 2, transferBytes, RESTART);
  // Set the COMMS_REQ_EN_BIT in CONFIG_SETTINGS
  transferBytes[0] |= COMMS_REQ_EN_BIT;
  // Write the bytes back to the device
  writeRandomBytes(IQS7211A_MM_CONFIG_SETTINGS, 2, transferBytes, stopOrRestart);
}

/**
  * @name   forceComms
  * @brief  A method to force a communication window while the RDY pin is high.
  * @retval None
  * @notes
  *         Once the stop bit is sent, the IQS7211A will pull the RDY pin low in a short time period.
  *         The IQS7211A is not ready for communications until the RDY pin is low.
  *         IMPORTANT - Comms Request EN bit needs to be set (1) to use this method.
  */
void IQS7211A::forceComms(void)
{
  uint8_t transferBytes[2];

  transferBytes[0] = 0x00;
  transferBytes[1] = 0x00;
  if (digitalRead(_readyPin))
  {
    /* Write any value to the force comms register */
    writeRandomBytes(IQS7211A_MM_FORCE_COMMS, 2, transferBytes, STOP);
  }
  //Wait for RDY low now.
}


/**
  * @name   updateInfoFlags
  * @brief  A method which reads the IQS7211A info flags and assigns them to the infoFlags union.
  * @param  stopOrRestart -> Specifies whether the communications window must be kept open or must be closed after this action.
  *              			 Use the STOP and RESTART definitions.
  * @retval None.
  * @notes  The infoFlags union is altered with the new value of the info flags register.
  */
void IQS7211A::updateInfoFlags(bool stopOrRestart)
{
	uint8_t transferBytes[2];	// The array which will hold the bytes to be transferred.

	// Read the info flags.
	readRandomBytes(IQS7211A_MM_INFOFLAGS, 2, transferBytes, stopOrRestart);
	// Assign the info flags to the info flags union.
  IQSMemoryMap.iqs7211a_info_flags.iqs7211a_infoflags_lsb =  transferBytes[0];
  IQSMemoryMap.iqs7211a_info_flags.iqs7211a_infoflags_msb =  transferBytes[1];
}

/**************************************************************************************************************/
/*											ADVANCED PUBLIC METHODS										  */
/**************************************************************************************************************/

/**
  * @name   writeMM
  * @brief  Function to write the whole memory map to the device (writable) registers 
  * @param  IQS7211A_init.h -> exported GUI init.h file
  * @retval None.
  * @notes  
  */
void IQS7211A::writeMM(bool stopOrRestart)
{
	uint8_t transferBytes[30];	// Temporary array which holds the bytes to be transferred.
    
  /* Change the ATI Settings */
  /* Memory Map Position 0x30 - 0x3D */
  transferBytes[0] = TP_ATI_MULTIPLIERS_DIVIDERS_0;             
  transferBytes[1] = TP_ATI_MULTIPLIERS_DIVIDERS_1;             
  transferBytes[2] = TP_COMPENSATION_DIV_0;                     
  transferBytes[3] = TP_COMPENSATION_DIV_1;                     
  transferBytes[4] = TP_ATI_TARGET_0;                           
  transferBytes[5] = TP_ATI_TARGET_1;                           
  transferBytes[6] = TP_REF_DRIFT_LIMIT_0;                      
  transferBytes[7] = TP_REF_DRIFT_LIMIT_1;                      
  transferBytes[8] = TP_MIN_COUNT_REATI_0;                      
  transferBytes[9] = TP_MIN_COUNT_REATI_1;                      
  transferBytes[10] = REATI_RETRY_TIME_0;                       
  transferBytes[11] = REATI_RETRY_TIME_1;                       
  transferBytes[12] = ALP_ATI_MULTIPLIERS_DIVIDERS_0;           
  transferBytes[13] = ALP_ATI_MULTIPLIERS_DIVIDERS_1;           
  transferBytes[14] = ALP_COMPENSATION_DIV_0;                   
  transferBytes[15] = ALP_COMPENSATION_DIV_1;                   
  transferBytes[16] = ALP_ATI_TARGET_0;                         
  transferBytes[17] = ALP_ATI_TARGET_1;                         
  transferBytes[18] = ALP_LTA_DRIFT_LIMIT_0;                    
  transferBytes[19] = ALP_LTA_DRIFT_LIMIT_1;                    

  /* Change the ALP ATI Compensation */
  /* Memory Map Position 0x3A - 0x3D */
  transferBytes[20] = ALP_COMPENSATION_A_0;                     
  transferBytes[21] = ALP_COMPENSATION_A_1;                     
  transferBytes[22] = ALP_COMPENSATION_B_0;                     
  transferBytes[23] = ALP_COMPENSATION_B_1;                     
  writeRandomBytes(IQS7211A_MM_TP_ATI_MIR, 24, transferBytes, RESTART);

  /* Change the Report Rates and Timing */
  /* Memory Map Position 0x40 - 0x4A */
  transferBytes[0] = ACTIVE_MODE_REPORT_RATE_0;                
  transferBytes[1] = ACTIVE_MODE_REPORT_RATE_1;                
  transferBytes[2] = IDLE_TOUCH_MODE_REPORT_RATE_0;            
  transferBytes[3] = IDLE_TOUCH_MODE_REPORT_RATE_1;            
  transferBytes[4] = IDLE_MODE_REPORT_RATE_0;                  
  transferBytes[5] = IDLE_MODE_REPORT_RATE_1;                  
  transferBytes[6] = LP1_MODE_REPORT_RATE_0;                   
  transferBytes[7] = LP1_MODE_REPORT_RATE_1;                   
  transferBytes[8] = LP2_MODE_REPORT_RATE_0;                   
  transferBytes[9] = LP2_MODE_REPORT_RATE_1;                   
  transferBytes[10] = ACTIVE_MODE_TIMEOUT_0;                    
  transferBytes[11] = ACTIVE_MODE_TIMEOUT_1;                    
  transferBytes[12] = IDLE_TOUCH_MODE_TIMEOUT_0;                
  transferBytes[13] = IDLE_TOUCH_MODE_TIMEOUT_1;                
  transferBytes[14] = IDLE_MODE_TIMEOUT_0;                      
  transferBytes[15] = IDLE_MODE_TIMEOUT_1;                      
  transferBytes[16] = LP1_MODE_TIMEOUT_0;                       
  transferBytes[17] = LP1_MODE_TIMEOUT_1;                      
  transferBytes[18] = REF_UPDATE_TIME_0;                        
  transferBytes[19] = REF_UPDATE_TIME_1;                        
  transferBytes[20] = I2C_TIMEOUT_0;                            
  transferBytes[21] = I2C_TIMEOUT_1;                            
  writeRandomBytes(IQS7211A_MM_ACTIVE_MODE_RR, 22, transferBytes, RESTART);

  /* Change the System Settings */
  /* Memory Map Position 0x50 - 0x5B */
  transferBytes[0] = SYSTEM_CONTROL_0;                         
  transferBytes[1] = SYSTEM_CONTROL_1;                         
  transferBytes[2] = CONFIG_SETTINGS0;                        
  transferBytes[3] = CONFIG_SETTINGS1;                         
  transferBytes[4] = OTHER_SETTINGS_0;                         
  transferBytes[5] = OTHER_SETTINGS_1;                         
  transferBytes[6] = TRACKPAD_TOUCH_SET_THRESHOLD;             
  transferBytes[7] = TRACKPAD_TOUCH_CLEAR_THRESHOLD;           
  transferBytes[8] = ALP_THRESHOLD_0;                          
  transferBytes[9] = ALP_THRESHOLD_1;                          
  transferBytes[10] = OPEN_0_0;                                 
  transferBytes[11] = OPEN_0_1;                                 
  transferBytes[12] = ALP_SET_DEBOUNCE;                         
  transferBytes[13] = ALP_CLEAR_DEBOUNCE;                       
  transferBytes[14] = OPEN_1_0;                                 
  transferBytes[15] = OPEN_1_1;                                 
  transferBytes[16] = TP_CONVERSION_FREQUENCY_UP_PASS_LENGTH;   
  transferBytes[17] = TP_CONVERSION_FREQUENCY_FRACTION_VALUE;   
  transferBytes[18] = ALP_CONVERSION_FREQUENCY_UP_PASS_LENGTH;  
  transferBytes[19] = ALP_CONVERSION_FREQUENCY_FRACTION_VALUE;  
  transferBytes[20] = TRACKPAD_HARDWARE_SETTINGS_0;             
  transferBytes[21] = TRACKPAD_HARDWARE_SETTINGS_1;             
  transferBytes[22] = ALP_HARDWARE_SETTINGS_0;                  
  transferBytes[23] = ALP_HARDWARE_SETTINGS_1;   
  writeRandomBytes(IQS7211A_MM_SYSTEM_CONTROL, 24, transferBytes, RESTART);               

  /* Change the Trackpad Settings */
  /* Memory Map Position 0x60 - 0x69 */
  transferBytes[0] = TRACKPAD_SETTINGS_0_0;                    
  transferBytes[1] = TRACKPAD_SETTINGS_0_1;                    
  transferBytes[2] = TRACKPAD_SETTINGS_1_0;                    
  transferBytes[3] = TRACKPAD_SETTINGS_1_1;                    
  transferBytes[4] = X_RESOLUTION_0;                           
  transferBytes[5] = X_RESOLUTION_1;                           
  transferBytes[6] = Y_RESOLUTION_0;                           
  transferBytes[7] = Y_RESOLUTION_1;                           
  transferBytes[8] = XY_DYNAMIC_FILTER_BOTTOM_SPEED_0;         
  transferBytes[9] = XY_DYNAMIC_FILTER_BOTTOM_SPEED_1;         
  transferBytes[10] = XY_DYNAMIC_FILTER_TOP_SPEED_0;            
  transferBytes[11] = XY_DYNAMIC_FILTER_TOP_SPEED_1;            
  transferBytes[12] = XY_DYNAMIC_FILTER_BOTTOM_BETA;            
  transferBytes[13] = XY_DYNAMIC_FILTER_STATIC_FILTER_BETA;     
  transferBytes[14] = STATIONARY_TOUCH_MOV_THRESHOLD;           
  transferBytes[15] = FINGER_SPLIT_FACTOR;                      
  transferBytes[16] = X_TRIM_VALUE_0;                           
  transferBytes[17] = X_TRIM_VALUE_1;                           
  transferBytes[18] = Y_TRIM_VALUE_0;                           
  transferBytes[19] = Y_TRIM_VALUE_1;  
  writeRandomBytes(IQS7211A_MM_TP_SETTINGS_0, 20, transferBytes, RESTART);                         

  /* Change the ALP Settings */
  /* Memory Map Position 0x70 - 0x74 */
  transferBytes[0] = ALP_COUNT_FILTER_BETA_0;                  
  transferBytes[1] = OPEN_0;                                   
  transferBytes[2] = ALP_LTA_BETA_LP1;                         
  transferBytes[3] = ALP_LTA_BETA_LP2;                         
  transferBytes[4] = ALP_SETUP_0;                              
  transferBytes[5] = ALP_SETUP_1;                              
  transferBytes[6] = ALP_TX_ENABLE_0;                          
  transferBytes[7] = ALP_TX_ENABLE_1;                          

  /* Change the Settings Version Numbers */
  /* Memory Map Position 0x74 - 0x75 */
  transferBytes[8] = MINOR_VERSION;                            
  transferBytes[9] = MAJOR_VERSION;
  writeRandomBytes(IQS7211A_MM_ALP_COUNT_FILTER_BETA, 10, transferBytes, RESTART);                                

  /* Change the Gesture Settings */
  /* Memory Map Position 0x80 - 0x8F */
  transferBytes[0] = GESTURE_ENABLE_0;                         
  transferBytes[1] = GESTURE_ENABLE_1;                         
  transferBytes[2] = TAP_TIME_0;                               
  transferBytes[3] = TAP_TIME_1;                               
  transferBytes[4] = TAP_DISTANCE_0;                           
  transferBytes[5] = TAP_DISTANCE_1;                           
  transferBytes[6] = HOLD_TIME_0;                              
  transferBytes[7] = HOLD_TIME_1;                              
  transferBytes[8] = SWIPE_TIME_0;                             
  transferBytes[9] = SWIPE_TIME_1;                             
  transferBytes[10] = SWIPE_X_DISTANCE_0;                       
  transferBytes[11] = SWIPE_X_DISTANCE_1;                       
  transferBytes[12] = SWIPE_Y_DISTANCE_0;                       
  transferBytes[13] = SWIPE_Y_DISTANCE_1;                       
  transferBytes[14] = SWIPE_ANGLE_0;                            
  transferBytes[15] = GESTURE_OPEN_0;
  writeRandomBytes(IQS7211A_MM_GESTURE_ENABLE, 16, transferBytes, RESTART);                              

  /* Change the RxTx Mapping */
  /* Memory Map Position 0x90 - 0x9C */
  transferBytes[0] = RX_TX_MAP_0;                              
  transferBytes[1] = RX_TX_MAP_1;                              
  transferBytes[2] = RX_TX_MAP_2;                              
  transferBytes[3] = RX_TX_MAP_3;                              
  transferBytes[4] = RX_TX_MAP_4;                              
  transferBytes[5] = RX_TX_MAP_5;                              
  transferBytes[6] = RX_TX_MAP_6;                              
  transferBytes[7] = RX_TX_MAP_7;                              
  transferBytes[8] = RX_TX_MAP_8;                              
  transferBytes[9] = RX_TX_MAP_9;                              
  transferBytes[10] = RX_TX_MAP_10;                             
  transferBytes[11] = RX_TX_MAP_11;                             
  transferBytes[12] = RX_TX_MAP_12;
  writeRandomBytes(IQS7211A_MM_RXTX_MAPPING_1_0, 13, transferBytes, RESTART);                           

  /* Change the Allocation of channels into cycles 0-9 */
  /* Memory Map Position 0xA0 - 0xBD */
  transferBytes[0] = PLACEHOLDER_0;                            
  transferBytes[1] = CH_1_CYCLE_0;                             
  transferBytes[2] = CH_2_CYCLE_0;                             
  transferBytes[3] = PLACEHOLDER_1;                            
  transferBytes[4] = CH_1_CYCLE_1;                             
  transferBytes[5] = CH_2_CYCLE_1;                             
  transferBytes[6] = PLACEHOLDER_2;                            
  transferBytes[7] = CH_1_CYCLE_2;                             
  transferBytes[8] = CH_2_CYCLE_2;                             
  transferBytes[9] = PLACEHOLDER_3;                            
  transferBytes[10] = CH_1_CYCLE_3;                             
  transferBytes[11] = CH_2_CYCLE_3;                             
  transferBytes[12] = PLACEHOLDER_4;                            
  transferBytes[13] = CH_1_CYCLE_4;                             
  transferBytes[14] = CH_2_CYCLE_4;                             
  transferBytes[15] = PLACEHOLDER_5;                            
  transferBytes[16] = CH_1_CYCLE_5;                             
  transferBytes[17] = CH_2_CYCLE_5;                             
  transferBytes[18] = PLACEHOLDER_6;                            
  transferBytes[19] = CH_1_CYCLE_6;                             
  transferBytes[20] = CH_2_CYCLE_6;                             
  transferBytes[21] = PLACEHOLDER_7;                            
  transferBytes[22] = CH_1_CYCLE_7;                             
  transferBytes[23] = CH_2_CYCLE_7;                             
  transferBytes[24] = PLACEHOLDER_8;                            
  transferBytes[25] = CH_1_CYCLE_8;                             
  transferBytes[26] = CH_2_CYCLE_8;                             
  transferBytes[27] = PLACEHOLDER_9;                            
  transferBytes[28] = CH_1_CYCLE_9;                             
  transferBytes[29] = CH_2_CYCLE_9;
  writeRandomBytes(IQS7211A_MM_CYCLE_SETUP_0_9, 30, transferBytes, RESTART);           

  /* Change the Allocation of channels into cycles 10-17 */
  /* Memory Map Position 0xB0 - 0xCA */
  transferBytes[0] = PLACEHOLDER_10;                           
  transferBytes[1] = CH_1_CYCLE_10;                            
  transferBytes[2] = CH_2_CYCLE_10;                            
  transferBytes[3] = PLACEHOLDER_11;                           
  transferBytes[4] = CH_1_CYCLE_11;                            
  transferBytes[5] = CH_2_CYCLE_11;                            
  transferBytes[6] = PLACEHOLDER_12;                           
  transferBytes[7] = CH_1_CYCLE_12;                            
  transferBytes[8] = CH_2_CYCLE_12;                            
  transferBytes[9] = PLACEHOLDER_13;                           
  transferBytes[10] = CH_1_CYCLE_13;                            
  transferBytes[11] = CH_2_CYCLE_13;                            
  transferBytes[12] = PLACEHOLDER_14;                           
  transferBytes[13] = CH_1_CYCLE_14;                            
  transferBytes[14] = CH_2_CYCLE_14;                            
  transferBytes[15] = PLACEHOLDER_15;                           
  transferBytes[16] = CH_1_CYCLE_15;                            
  transferBytes[17] = CH_2_CYCLE_15;                            
  transferBytes[18] = PLACEHOLDER_16;                           
  transferBytes[19] = CH_1_CYCLE_16;                            
  transferBytes[20] = CH_2_CYCLE_16;
  transferBytes[21] = PLACEHOLDER_17;
  transferBytes[22] = CH_1_CYCLE_17;
  transferBytes[23] = CH_2_CYCLE_17;
  writeRandomBytes(IQS7211A_MM_CYCLE_SETUP_10_17, 24, transferBytes, stopOrRestart);

}

// /**************************************************************************************************************/
// /*                                              PRIVATE METHODS                                                */
// /**************************************************************************************************************/

/**
 * @name    readRandomBytes
 * @brief   A methods which reads a specified number of bytes from a specified address and saves it into a user supplied array.
 *          This method is used by all other methods in this class which read data drom the IQS7211A device.
 * @param   memoryAddress -> The memory address at which to start reading bytes from.  See the "iqs7211a_addresses.h" file.
 *          numBytes      -> The number of bytes that must be read.
 *          bytesArray    -> The array which will store the bytes to be read, this array will be overwritten.
 *          stopOrRestart -> A boolean which specifies whether the communication window should remain open or be closed after transfer.
 *                           False keeps it open, true closes it. Use the STOP and RESTART definitions. 
 * @retval  No value is returend, however, the user supplied array is overwritten.
 * @notes   Uses standard arduino "Wire" library which is for I2C communication.
 *          Take note that C++ cannot return an array, therefore, the array which is passed as an argument is overwritten with the required values.
 *          Pass an array to the method by using only its name, e.g. "bytesArray", without the brackets, this basically passes a pointer to the array.
 */
void IQS7211A::readRandomBytes(uint8_t memoryAddress, uint8_t numBytes, uint8_t bytesArray[], bool stopOrRestart)
{
  uint8_t i = 0;  // A simple counter to assist with loading bytes into the user supplied array.
  
  // Select the device with the address of "_deviceAddress" and start communication.
  Wire.beginTransmission(_deviceAddress);
  // Send a bit asking for the "memoryAddress" register.
  Wire.write(memoryAddress);
  // Complete the selection and communication initialization.
  Wire.endTransmission(RESTART);  // Restart transmission for reading that follows.
  // The required device has now been selected and it has been told which register to send information from.

  // Request "numBytes" bytes from the device which has address "_deviceAddress"
  do
  {
    Wire.requestFrom(_deviceAddress, numBytes, stopOrRestart);
  }while(Wire.available() == 0);  // Wait for response, this sometimes takes a few attempts

  // Load the received bytes into the array until there are no more 
  while(Wire.available())
  {
    // Load the received bytes into the user supplied array
    bytesArray[i] = Wire.read();
    i++;
  }
// And Bob's your uncle.
}

/**
  * @name   writeRandomBytes
  * @brief  A mthod which writes a specified number of bytes to a specified address, the bytes to write are supplied by means of an array pointer.
  *         This method is used by the all other methods of this class which write data to the IQS7211A device.
  * @param  memoryAddress -> The memory address at which to start writing the bytes to. See the "iqs7211a_addresses.h" file.
  *         numBytes      -> The number of bytes that must be written.
  *         bytesArray    -> The array which stores the bytes which will be written to the memory location.
  *         stopOrRestart -> A boolean which sepcifies whether the communication window should remain open or be closed of transfer.
  *                          False keeps it open, true closes it. Use the STOP and RESTART definitions.
  * @retval No value is returend, only the IQS device registers are altered.
  * @notes  Uses standard arduino "Wire" library which is for I2C communication.
  *         Take note that a full array cannot be passed to a function in C++.
  *         Pass an array to the function by using only its name, e.g. "bytesArray", without the square brackets, this basically passes a pointer to the array.
  *         The values to be written must be loaded into the array prior to passing it to the function.
  */
void IQS7211A::writeRandomBytes(uint8_t memoryAddress, uint8_t numBytes, uint8_t bytesArray[], bool stopOrRestart)
{
  // Select the device with the address of "_deviceAddress" and start communication.
  Wire.beginTransmission(_deviceAddress);
  // Specify the memory address where the IQS7211A must start saving the data, as designated by the "memoryAddress" variable.
  Wire.write(memoryAddress);
  // Write the bytes as specified in the array which "arrayAddress" pointer points to.
  for(int i=0; i<numBytes; i++)
  {
    Wire.write(bytesArray[i]);
  }
  // End the transmission, user decides to STOP or RESTART.
  Wire.endTransmission(stopOrRestart);
}