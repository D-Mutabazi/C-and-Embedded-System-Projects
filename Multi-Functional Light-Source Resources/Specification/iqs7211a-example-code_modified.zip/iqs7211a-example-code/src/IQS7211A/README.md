# IQS7211A Library
The IQS7211A library is a library which allows easy setup and interaction with the Azoteq IQS7211A. Versatile Trackpad/Touchscreen controller with proximity, touch, trackpad and gesture outputs. The IQS7211A ProxFusion® IC is a capacitive touch and proximity trackpad/touchscreen controller implementation. The IQS7211A features best in class sensitivity, signal-to-noise ratio and automatic tuning of electrodes. Low power proximity detection allows extreme low power operation.

The IQS7211A requires an I2C master to setup for custom application requirements.
See the list of functions below.

Since the IQS7211A interacts with the MCU via I2C communication, this library is based on the standard Arduino
"Wire.h" library and is thus supported by any hardware which is supported by the "Wire.h" library. The "Wire.h" library
is included within the "IQS7211A.h" library and does not need to be included again. Furthermore, a Wire instance is 
created in the IQS7211A::begin() function and does not need to be created in the Setup() section of the Arduino sketch. 
The user does not need to interact with the "Wire.h" library at all.

# IQS7211A Device
Information on the IQS7211A device can be found her: https://www.azoteq.com/product/iqs7211a/
The datasheet can be downloaded from this link: https://www.azoteq.com/product/iqs7211a/
Any application notes can be found here: https://www.azoteq.com/design/application-notes/

# Methods:
Method names are mostly self explanatory. However, there is also a short commented header above each method
in the "IQS7211A.cpp" file which offers a brief explanation and description of parameters and return values. Also
see the "IQS7211A.h" file for all the method prototypes.

    bool begin(uint8_t deviceAddressIn, uint8_t readyPinIn, uint8_t mclrPinIn);
    bool waitForReady(void);
    uint16_t getProductNum(bool stopOrRestart);
    uint8_t getSoftwareMajorNum(bool stopOrRestart);
    uint8_t getSoftwareMinorNum(bool stopOrRestart);
    void acknowledgeReset(bool stopOrRestart);
    void TP_ReATI(bool stopOrRestart);
    void SW_Reset(bool stopOrRestart);
    void writeMM(bool stopOrRestart);
    void updateAbsCoordinates(bool stopOrRestart, uint8_t fingerNum);
    uint16_t getAbsXCoordinate(uint8_t fingerNum);
    uint16_t getAbsYCoordinate(uint8_t fingerNum);
    void updateGestures(bool stopOrRestart);
    void setStreamMode(bool stopOrRestart);
    void setEventMode(bool stopOrRestart);
    void IQS7211A::enableGestureEvent(bool stopOrRestart);
    void IQS7211A::disableGestureEvent(bool stopOrRestart);
    void IQS7211A::enableTPEvent(bool stopOrRestart);
    void IQS7211A::disableTPEvent(bool stopOrRestart)
    void IQS7211A::disableCommsReqEn(bool stopOrRestart);
    void IQS7211A::enableCommsReqEn(bool stopOrRestart);
    void IQS7211A::forceComms(void);
    void updateInfoFlags(bool stopOrRestart);
    bool checkReset(void);

# I2C Communication:
The IQS7211A communicates with the master MCU through I2C communication. However, the IQS7211A has an additional "Ready" line which
can let the master know when it has information available. This is particularly useful as it allows the MCU to service the IQS7211A
on an interrupt basis rather than polling it. More on "Event Mode" and "Stream Mode" later.

Most functions of th IQS7211A library have a boolean parameter as the last parameter named stopOrRestart. This boolean indicates
wether the current communication window must be kept open or closed. Use STOP or RESTART as defined in the library header.
When calling multiple functions in a block of code with the same IQS7211A instance all functions except for the last should 
use RESTART and the last function should then use STOP. See the accompanied examples.

# Event Mode and Stream Mode:
The IQS7211A starts up in Stream Mode, however, Event Mode is very convenient as the user can select which events are important.
The device can be set up to bypass the communication window when no activity is sensed (Event
Mode). This is usually enabled since the master does not want to be interrupted unnecessarily during
every cycle if no activity occurred. The communication will resume (RDY will indicate available data)
if an enabled event occurs. It is recommended that the RDY be placed on an interrupt-on-pin-change
input on the master.

In Stream Mode the IQS device pulls the ready line low in specified intervals which lets the MCU know that the latest sensing
information is now avialable to be read. This is done regardless of whether an event is detected or not. In this way the MCU can
decide when it wants to read information polling the ready line and reading the information it needs as soon as it is available. Unless
the MCU checks on the IQS device regularly it can miss events.

# Requesting Communication:
In stream mode the ready pin is pulled low frequently, when the ready line is LOW the MCU can innitiate communication with the IQS device.
The waitForReady() function can be used to wait for the ready pin to go LOW, the waitForReady() function waits until the ready pin is
LOW and then returns a TRUE. If the ready pin does not go LOW within 100ms it returns FALSE. The function can be put in a while loop to
continue calling it until the ready pin is pulled LOW.

In event mode there might be long periods where no event occurs, then the ready pin is not pulled low by the IQS device. The master can initiate communication even while RDY is HIGH (inactive). The default method is that the IQS721A will clock stretch until an appropriate time to complete the I2C transaction. The master
firmware will not be affected (if clock stretching is correctly handled). 

If the associated clock stretching cannot be allowed, then an alternative comms request method
can be enabled (Comms Request EN). To achieve this, the master will do communication when RDY
is not active (thus forcing comms), and it will write a comms request to the device.

# Events
In Event Mode an event causes the IQS7211A to pull the Ready pin LOW if that event is enabled. This event is then stored in the Events register
until the current communication window is closed.
In Stream Mode any occuring event is kept in the Events register until the next conversion cycle which then loads the new events.

To really understand how the events work the IQS7211A datasheet can be consulted.
				
That covers the basics. When in doubt, consult the device datasheet. Azoteq also offers an evaluation kit, configuration tool and free GUI based PC software
which makes it easy to configure settings from basic to advanced and visualize what is happening inside the device.
See this page for the EV kit and PC software: http://www.azoteq.com/design/evaluation-kits.html
